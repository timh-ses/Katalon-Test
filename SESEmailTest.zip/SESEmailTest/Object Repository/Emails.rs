<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Emails</name>
   <tag></tag>
   <elementGuidId>bba7709b-cd7a-4a47-9281-7a259ba4a649</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
