<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_Move to</name>
   <tag></tag>
   <elementGuidId>f1463bd7-ef74-4e77-9482-189b999733e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='pm_main']/nav</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>toolbarDesktop-container pm_toolbar pm_toolbar_withSelector</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        
            
                
                
                    
                    
                    
                
            

            
            
            
            

                
            
        
        
        
            
            
        
        
        
            
            
            
        
        
        
            
                
                
            
            
                
                    
                        Move to
                    
                    
                        
                            
                                
                                    
                                        
                                        Trash
                                    
                                
                            
                        
                    

                    

                
            
        


        
        
             More  
            

                
                      Size: Small to large 
                
                
                      Size: Large to small 
                 
                
                      Date: New to old 
                
                
                      Date: Old to new 
                
                
                      Show all 
                
                
                      Show unread 
                
                
                      Show read 
                 
            
        
        
        
            
            eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSIsImtpZCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSJ9.eyJpc3MiOiJodHRwczovL3NlcnZpY2UyLmRpcmVjdGFkZHJlc3MubmV0L2lkZW50aXR5IiwiYXVkIjoiaHR0cHM6Ly9zZXJ2aWNlMi5kaXJlY3RhZGRyZXNzLm5ldC9pZGVudGl0eS9yZXNvdXJjZXMiLCJleHAiOjE1ODc5MzEzMTEsIm5iZiI6MTU4NzkyNzcxMSwiY2xpZW50X2lkIjoic3NvX3dlYm1haWwiLCJzY29wZSI6WyJvcGVuaWQiLCJwcm9maWxlIiwicm9sZXMiLCJhZGRyZXNzIiwicmVnQXBpIiwib2ZmbGluZV9hY2Nlc3MiXSwic3ViIjoiOTA3OGMxNTYtOTdjMS00M2FhLWEwMzUtYTRjNDFkZGE2Y2Y4IiwiYXV0aF90aW1lIjoxNTg3OTI3Njk2LCJpZHAiOiJpZHNydiIsInByZWZlcnJlZF91c2VybmFtZSI6IlNlc1Rlc3R8c2VydmljZTIuZGlyZWN0YWRkcmVzcy5uZXQiLCJlbWFpbCI6InRoYXJnYW5Ac2VjdXJlZXhzb2x1dGlvbnMuY29tIiwiZW1haWxfdmVyaWZpZWQiOiJ0cnVlIiwicm9sZSI6WyJFTlNBY2Nlc3MiLCJBZG1pbmlzdHJhdG9yIiwiVXNlciIsIkNyZWF0ZVVzZXJzIl0sIm5hbWUiOiJNciBzZXMgdGVzdHVzZXIiLCJnaXZlbl9uYW1lIjoic2VzIiwiZmFtaWx5X25hbWUiOiJ0ZXN0dXNlciIsImFkZHJlc3MiOiJ7XCJzdHJlZXRfYWRkcmVzc1wiOlwiMTE0MTAgSXNhYWMgTmV3dG9uIFNxXCIsXCJsb2NhbGl0eVwiOlwiUmVzdG9uXCIsXCJyZWdpb25cIjpcIlZBXCIsXCJwb3N0YWxfY29kZVwiOlwiMjAxOTBcIixcImNvdW50cnlcIjpcIlVTQVwifSIsInBob25lX251bWJlciI6Ijg4ODQ3MDk5MyIsInNlc3VzZXJfaWQiOiIyNzAyOCIsInZlbmRvcl9pZCI6IjgyIiwib3JnX2lkIjoiMzI5MiIsImRvbWFpbl9uYW1lIjoic2VydmljZTIuZGlyZWN0YWRkcmVzcy5uZXQiLCJkaXJlY3RfZW1haWwiOiJub3RpZnlfdGVzdEBzZXJ2aWNlMi5kaXJlY3RhZGRyZXNzLm5ldCIsInVzZXJfdHlwZSI6IlByb2Zlc3Npb25hbCIsImFtciI6WyJwYXNzd29yZCJdfQ.G2HPPL0CBRxFSXKLMoyaXN6nU9ycpHiJ8wVAyt2RbefNCjoAwtznfkTPtVzwmBbwoTWl4tl2WlhUlEW1w7OmLgICPJIJArB9AAbaqg35Vk1DIotAYcwWt-rFy4xqGKF-NDdHLjr3DtkgnwtozXBqJHkdSYCnEdUEL_5142RR31uP4oIVF4KIOpzr_xVjG-p7-cudilwcS_nENgHvisiRqRLgSDKOpGf09r6xJ5n5LsMteKslGjqNiszLx3UZgoL7v8MkGn_smCYdBpVcAcCxIOB7ISNSiWr60SzwTv0trgnkiusQ0lEtNxCZarlVZtgtjAoRc_9-YXogow5rgiZX9w
            c0ad5c7969cf90037e1981b8a32a5b96
            4/26/2020 8:01:51 PM
            4/26/2020 8:01:51 PM +00:00
            https://service2.directaddress.net
            
                
                    123456
                
            
            
        
        
        
        
            
                
                    
                
            
            
             Contacts

            

        

    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pm_main&quot;)/nav[@class=&quot;toolbarDesktop-container pm_toolbar pm_toolbar_withSelector&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='pm_main']/nav</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='something'])[1]/following::nav[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
   </webElementXpaths>
</WebElementEntity>
